import React from 'react';

function PostList({ posts }) {
  return (
    <div>
      <h3>Posts</h3>
      <ul>
        {posts.map((post, index) => (
          <li key={index}>{post.content}</li>
        ))}
      </ul>
    </div>
  );
}

export default PostList;
