import React from 'react';

function DiscussionList({ discussions }) {
  return (
    <div>
      <h2>Discussions</h2>
      <ul>
        {discussions.map((discussion, index) => (
          <li key={index}>
            <a href="#">{discussion.title}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default DiscussionList;
