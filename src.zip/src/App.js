import React, { useState, useEffect } from 'react';
import DiscussionList from './DiscussionList';
import DiscussionForm from './DiscussionForm';

function App() {
  const [discussions, setDiscussions] = useState([]);

  useEffect(() => {
    // Load discussions from localStorage (or use default empty array)
    const savedDiscussions = JSON.parse(localStorage.getItem('discussions')) || [];
    setDiscussions(savedDiscussions);
  }, []);

  useEffect(() => {
    // Save discussions to localStorage whenever the discussions state changes
    localStorage.setItem('discussions', JSON.stringify(discussions));
  }, [discussions]);

  return (
    <div className="App">
      <h1>Discussion Board</h1>
      <DiscussionForm setDiscussions={setDiscussions} />
      <DiscussionList discussions={discussions} />
    </div>
  );
}

export default App;

