import React, { useState } from 'react';

function PostForm({ setPosts }) {
  const [content, setContent] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!content.trim()) {
      alert('Post content cannot be empty!');
      return;
    }
    const newPost = { content };
    setPosts((prevPosts) => [...prevPosts, newPost]);
    setContent('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Write a post..."
      />
      <button type="submit">Post</button>
    </form>
  );
}

export default PostForm;
