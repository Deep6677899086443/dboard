import React, { useState } from 'react';

function DiscussionForm({ setDiscussions }) {
  const [title, setTitle] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Discussion title cannot be empty!');
      return;
    }
    const newDiscussion = { title };
    setDiscussions((prevDiscussions) => [...prevDiscussions, newDiscussion]);
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter discussion title"
      />
      <button type="submit">Create Discussion</button>
    </form>
  );
}

export default DiscussionForm;
